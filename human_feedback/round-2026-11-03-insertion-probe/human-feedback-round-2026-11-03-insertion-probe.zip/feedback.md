# emoji-picker — Can we put an emoji into your apps cleanly? (Wayland + GNOME)

Round: round-2026-11-03-insertion-probe
Tested version: 4f91bd5
Date: 11/5/2026, 10:48:31 AM
Tester: not provided
Browser/device: not provided

## Checks tried

### 0. Environment report and self-test (no changes, 1 minute) (tried)
Run ./env-report.sh, then python3 ibus/selftest.py (it uses its own private IBus and touches none of your settings). Paste the output of both into the box below, or just say if either failed to run. Note anything surprising, such as a missing package.

frank@frank-ThinkPad-X1-Yoga-Gen-6:~/Dev/emoji-picker/probe$  ./env-report.sh
# emoji-picker probe: environment report
date: 2026-11-05T10:35:17-05:00

## Session
XDG_SESSION_TYPE=wayland
XDG_CURRENT_DESKTOP=ubuntu:GNOME
WAYLAND_DISPLAY=wayland-0  DISPLAY=:0
GTK_IM_MODULE= QT_IM_MODULE=ibus XMODIFIERS=@im=ibus
Ubuntu 26.04.1 LTS
7.0.0-38-generic
GNOME Shell 50.1

## IBus
IBus 1.5.34-rc2
running daemon: yes
active engine: xkb:us::eng
input sources: [('xkb', 'us')]
per-window source: false

## Portals (Wayland insertion needs RemoteDesktop)
RemoteDesktop.version: (<uint32 2>,)
RemoteDesktop.AvailableDeviceTypes: (<uint32 7>,)
GlobalShortcuts.version: (<uint32 1>,)
xdg-desktop-portal 1.21.1+ds-1ubuntu3.1
xdg-desktop-portal-gnome 50.0-0ubuntu1
xdg-desktop-portal-gtk 1.15.3-2ubuntu1

## Injection helpers
wl-copy: /usr/bin/wl-copy
wl-paste: /usr/bin/wl-paste
wtype: no
ydotool: no
xdotool: no
xclip: /usr/bin/xclip
crw-rw----+ 1 root input 10, 223 Oct 29 09:12 /dev/uinput
groups: frank adm cdrom sudo dip plugdev users lpadmin lxd docker

## Python / GTK bindings
Python 3.14.4
Gtk 4.0: ok
Adw 1: ok
IBus 1.0: ok
Gio 2.0: ok

## Apps for the test matrix (snap/flatpak change IME and portal behaviour)
firefox: /usr/bin/firefox
google-chrome: /usr/bin/google-chrome
ptyxis: /usr/bin/ptyxis
gnome-text-editor: /usr/bin/gnome-text-editor
libreoffice: /snap/bin/libreoffice
snap: 1password 8.11.14
snap: bare 1.0
snap: collabora-office 26.04.4.3
snap: core18 20260901
snap: core20 20260901
snap: core22 20260909
snap: core24 20260824
snap: core26 20260925
snap: cups 2.4.20-1
snap: desktop-security-center 0+git.4adf2b9
snap: ffmpeg-2204 8.1
snap: firefox 158.0.1-1
snap: firmware-updater 0+git.64c41a0
snap: gaming-graphics-core24 25.2.2~kisak1~n
snap: gimp 3.2.8
snap: gnome-3-28-1804 3.28.0-19-g98f9e67.98f9e67
snap: gnome-42-2204 0+git.4982e7b-sdk0+git.69b626a
snap: gnome-46-2404 0+git.b31ceab-sdk0+git.f0723a0
snap: gnome-core26 0+git.d122561-sdk0+git.1ee381d
snap: gtk-common-themes 0.1-81-g442e511
Gradia	be.alexandervanhee.gradia	1.13.0	stable	system
Authenticator	com.belmoussaoui.Authenticator	4.6.2	stable	system
Reco	com.github.ryonakano.reco	5.2.1	stable	system
Parabolic	org.nickvision.tubeconverter	2026.5.0	stable	system

Saved to: /home/frank/Dev/emoji-picker/probe/emoji-probe-report.txt
frank@frank-ThinkPad-X1-Yoga-Gen-6:~/Dev/emoji-picker/probe$ python3 ibus/selftest.py
[PASS] private ibus-daemon starts
[PASS] daemon loads the emojitest component
[PASS] engine process starts and listens  (51 ms)
[PASS] engine reports a focused context  (50 ms)
/usr/lib/python3/dist-packages/gi/overrides/GLib.py:597: Warning: g_object_is_floating: assertion 'G_IS_OBJECT (object)' failed
  return super().iteration(may_block)
[PASS] commit reaches the client  (reply='ok' got=['👨\u200d👩\u200d👧\u200d👦'])
[NOTE] commit while no app has focus: reply='ok' (accepted then dropped by IBus: fake context)
/usr/lib/python3/dist-packages/gi/overrides/GLib.py:597: Warning: g_object_is_floating: assertion 'G_IS_OBJECT (object)' failed
  return super().iteration(may_block)
[PASS] commit works again after focus returns  (focus-to-commit 20 ms)

--- engine.log ---
10:35:27.897 engine started, pid 3466575
10:35:27.898 focus_in
10:35:27.898 enable
10:35:27.898 set_capabilities 0x29
10:35:27.913 focus_out
10:35:27.913 focus_in
10:35:27.913 set_capabilities 0x8
10:35:28.014 commit '👨\u200d👩\u200d👧\u200d👦': sent
10:35:28.066 focus_out
10:35:28.066 focus_in
10:35:28.066 set_capabilities 0x29
10:35:28.368 commit '😀': sent
10:35:28.368 focus_out
10:35:28.368 focus_in
10:35:28.368 set_capabilities 0x8
10:35:28.388 commit '😀': sent

6/6 checks passed
frank@frank-ThinkPad-X1-Yoga-Gen-6:~/Dev/emoji-picker/probe$ 


### 1. Your current picker, as a baseline (not marked tried; something to report)
Open your usual emoji picker the way you normally do (say which shortcut) in three different apps and insert an emoji. For each app: does the picker open every time? Is anything left behind, such as stray characters, a letter, or an underlined fragment? What does the leftover look like?

I don't know if it's because I ran the setup script and uninstalled, but i can no longer access my emoji picker.
I normally press windows + . and it shows an "e".  I press spacebar and it allows me to choose.  I tested in 3 apps and I can't open the picker in any of them.

### 2. Install the test engine (tried)
Run ./setup.sh install and enter your password when asked. Then switch your input source to Emoji Probe (passive) with Super+Space (or the keyboard indicator in the top bar). Type normally for a minute: does typing in your usual layout still work exactly as before? Report any dropped, doubled or wrong keys.

Typing still works as normal.  Test test.  Hello World!  I'm using the Emoji Probe I believe.  Nothing feels weird yet.



### 3. Insert through the input method (Ctrl+Alt+1) (tried)
In an app, click into a text box, press Ctrl+Alt+1, click an emoji in the small window. The window closes and the emoji should appear where your cursor was. Try all six emoji in each app. Note, per app: did it appear? Was it the right one (family, flag, skin tone intact)? Was anything left behind? Did the cursor end up where it should? Then open ~/.local/state/emojitest/picker.log and paste the last lines: it records how long focus took to return.

😀👍🏽❤️👨‍👩‍👧‍👦🏳️‍🌈🇨🇦

control + alt + 1 inserting emojis works.  cursor test 😀, yes the cursor is where it should be.

10:39:38.546 picker start: mode=ime delay=150ms session=wayland
10:39:41.549 picked 😀 (plain)
10:39:41.751 IME commit ok after 51 ms of waiting for focus
10:39:42.897 picker start: mode=ime delay=150ms session=wayland
10:39:44.733 picker start: mode=ime delay=150ms session=wayland
10:39:52.725 picked 👍🏽 (skin tone)
10:39:52.926 IME commit ok after 50 ms of waiting for focus
10:40:01.148 picker start: mode=ime delay=150ms session=wayland
10:40:02.750 picked ❤️ (VS16)
10:40:02.952 IME commit ok after 50 ms of waiting for focus
10:40:04.255 picker start: mode=ime delay=150ms session=wayland
10:40:06.069 picker start: mode=ime delay=150ms session=wayland
10:40:06.467 picker start: mode=ime delay=150ms session=wayland
10:40:08.867 picked 👨‍👩‍👧‍👦 (ZWJ family)
10:40:09.068 IME commit ok after 50 ms of waiting for focus
10:40:18.713 picker start: mode=ime delay=150ms session=wayland
10:40:20.283 picked 👨‍👩‍👧‍👦 (ZWJ family)
10:40:20.484 IME commit ok after 50 ms of waiting for focus
10:40:22.627 picker start: mode=ime delay=150ms session=wayland
10:40:24.108 picked 🏳️‍🌈 (ZWJ flag)
10:40:24.309 IME commit ok after 50 ms of waiting for focus
10:40:25.380 picker start: mode=ime delay=150ms session=wayland
10:40:27.938 picker start: mode=ime delay=150ms session=wayland
10:40:29.683 picked 🇨🇦 (regional flag)
10:40:29.885 IME commit ok after 50 ms of waiting for focus
10:40:52.079 picker start: mode=ime delay=150ms session=wayland
10:40:54.078 picked 😀 (plain)
10:40:54.281 IME commit ok after 51 ms of waiting for focus


### 4. Insert by pasting for you (Ctrl+Alt+2) (tried)
Press Ctrl+Alt+2. A permission dialog should appear the first time: describe what it says and whether it is clear or alarming. Pick an emoji. Does it paste? Then repeat in the same app: does it ask permission again? Try it in your terminal as well: terminals use Ctrl+Shift+V, so a plain Ctrl+V may do nothing there, and we want to know.

😀👍🏽❤️

It asked me for a remote desktop connection and whether I should allow something.  I then clicked "share" and now the picker works like before.  

control + alt + 2 doesn't really work in the terminal.  control + alt + 1 does work in the terminal.

It only asks permission once.

### 5. Copy only (Ctrl+Alt+3) (tried)
Press Ctrl+Alt+3, pick an emoji, then paste yourself in two apps. Does the emoji stay on the clipboard after the small window closes? (Whether it does tells us if we need to keep a background process running.)

😀😀😀😀🏳️‍🌈🏳️‍🌈🏳️‍🌈🏳️‍🌈🇨🇦🇨🇦🇨🇦🇨🇦

Pasting with control alt 3 works.  It does stay in the clipboard after the small window closes.

### 6. How did it feel overall? (tried)
Compared with your current picker, which route felt best? Was there a visible delay between clicking an emoji and it appearing? Did the window ever fail to open, or open on the wrong screen or behind another window? Any moment where you thought: that is annoying.

I guess the first option, control + alt + 1 works best because it works in the terminal as well.  Being able to press enter instead of using a mouse click is a must. 

### 7. Clean up (not marked tried)
Run ./setup.sh uninstall (password again). Confirm your input sources and shortcuts are back to normal, and tell us if anything was left changed.

frank@frank-ThinkPad-X1-Yoga-Gen-6:~/Dev/emoji-picker/probe$  ./setup.sh uninstall
Restored input sources
Restored shortcuts list

(ibus write-cache:3480616): IBUS-WARNING **: 10:47:21.899: Engines exec:/usr/libexec/ibus-engine-table --xml is failed: 
Removed engine. Logs and backups remain in /home/frank/.local/state/emojitest (safe to delete).
frank@frank-ThinkPad-X1-Yoga-Gen-6:~/Dev/emoji-picker/probe$ 

The old input method works again.  😑

## Overall impression

Overall: not provided

### Worked well
No answer.

### Improve first
No answer.

### Other notes
No answer.

## Screenshots

No screenshots attached.

Vocabulary shown to the tester:
- Input method (IBus): The system component that turns key presses into text, and the same one used for typing Chinese or Japanese. It can hand text straight to an app without using the clipboard.
- Portal: A permission system for sandboxed and Wayland apps. Here it lets the test press keys for you after you approve a dialog.
- Clipboard: The place copied text waits for you to paste it.
- Stray characters: Anything left in the app that you did not mean to type, such as a letter, a number, or underlined text that should have vanished.
- Focus: Which window is currently receiving your typing.